感谢一直以来对《CYL-科技》youtube频道的支持

**分流规则**

https://raw.githubusercontent.com/lhie1/Rules/master/Shadowrocket/Complete.conf

规则：

DOMAIN-SUFFIX                      域名后缀

DOMAIN-KEYWORD                包含关键字

DOMAIN                                   完全匹配

DOMAIN-SET                           域集（见注释）

USER-AGENT                           用户代理（见注释）

URL-REGEX                              URL正则表达式

IP-CIDR                                     IP段匹配

RULE-SET                                 规则匹配

SCRIPT                                      脚本

GEOIP                                       国家代码

FINAL                                        不符合之前所有就走这条规则



【注释】：

有关 《用户代理》跟《URL正则表达式》参考以下：

https://github.com/nondanee/UnblockNeteaseMusic/issues/368

https://blog.walterlv.com/post/match-web-url-using-regex.html#url
